# from reportlab.lib.pagesizes import letter
# from reportlab.lib import colors
# from reportlab.platypus import SimpleDocTemplate, Image, Paragraph, Spacer
# from reportlab.lib.styles import getSampleStyleSheet
# from reportlab.lib.units import inch
# from reportlab.pdfgen import canvas
# from datetime import *

# # Create a function to generate the PDF report
# def generate_pdf_report(pdf_file, organization_name, report_date, logo_path, content):
#     # Create a PDF document
#     doc = SimpleDocTemplate(pdf_file, pagesize=letter)

#     # Create a story (list of elements to include in the PDF)
#     story = []

#     # Add the organization name
#     styles = getSampleStyleSheet()
#     organization_style = styles["Heading1"]
#     organization_style.alignment = 1  # Center align
#     story.append(Paragraph(organization_name, organization_style))

#     # Add the date
#     date_style = styles["Normal"]
#     story.append(Paragraph(report_date, date_style))
#     story.append(Spacer(1, 0.2 * inch))  # Add some space between the header and content

#     # Add the logo
#     logo = Image(logo_path, width=2 * inch, height=1 * inch)
#     story.append(logo)
#     story.append(Spacer(1, 0.2 * inch))  # Add some space between the logo and content

#     # Add the content of the report
#     content_style = styles["Normal"]
#     story.append(Paragraph(content, content_style))

#     # Build the PDF document
#     doc.build(story)

# # Specify the details for the PDF report


